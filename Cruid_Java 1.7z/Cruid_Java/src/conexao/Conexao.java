/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexao;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author enzo.aralvesi
 */
public class Conexao {
       public Connection getConexao(){
        try{
            //Estabeler conex�o
            Connection conn = DriverManager.getConnection(
                      "jdbc:mysql://localhost:3306/bdhopital", //linha de conex�o
                      "root", //usuario do mysql
                      "" //senha
            );
            return conn; 
        }catch( Exception e){
        //erro na conex�o
        System.out.println("Erro conex�o: " + e.getMessage());
        return null;
        }
    }
}
