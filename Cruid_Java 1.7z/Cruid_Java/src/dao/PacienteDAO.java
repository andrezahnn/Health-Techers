
package dao;

import beans.Paciente;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAO {
    private Conexao conexao;
    private Connection conn;
    
    public PacienteDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    public void inserir(Paciente paciente){
        String sql = "INSERT INTO paciente (nome, data_nasc, sexo, telefone, email, endereco) VALUES (?,?,?.?,?,?) ";
        
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, paciente.getNome() );
            stmt.setString(2, paciente.getDataNascimento());
            stmt.setString(3,paciente.getSexo());
            stmt.setString(4,paciente.getTelefone());
            stmt.setString(5,paciente.getEmail());
            stmt.setString(6,paciente.getEndereco());
            stmt.execute();
        }catch(Exception e){
            System.out.println("Erro ao inserir paciente: "+ e.getMessage());
        }
    }
    
    public void alterar(Paciente paciente){
        String sql = "UPDATE paciente SET nome=?, data_nasc=?, sexo=?, telefone=?, email=?, endereco=? WHERE id=?";
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, paciente.getNome());
            stmt.setString(2, paciente.getDataNascimento());
            stmt.setString(3,paciente.getSexo());
            stmt.setString(4,paciente.getTelefone());
             stmt.setString(5,paciente.getEmail());
              stmt.setString(6,paciente.getEndereco());
            stmt.execute();
        }catch(Exception e){
            System.out.println("Erro ao atualizar produto: "+ e.getMessage());
        }
    }
    
    public void excluir(int idPaciente){
        String sql = "DELETE FROM paciente WHERE id = ?";
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1,idPaciente);
            stmt.execute();
        }catch(Exception e){
            System.out.println("Erro ao excluir paciente: "+ e.getMessage());
        }
    }
    
    public Paciente getPaciente(int idPaciente){
        String sql = "SELECT * FROM paciente WHERE id_Paciente =?";
        
        try{
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1, idPaciente);
            ResultSet rs = stmt.executeQuery();
            Paciente paciente = new Paciente();
            rs.next();
            paciente.setIdPaciente(rs.getInt("id_Paciente"));
            paciente.setNome(rs.getString("nome"));
            paciente.setDataNascimento(rs.getString("data_nasc"));
            paciente.setTelefone(rs.getString("telefone"));
            paciente.setEmail(rs.getString("email"));
            paciente.setEndereco(rs.getString("endereco"));
            return paciente;
        
        }catch(Exception e){
            System.out.println("Erro ao atualizar paciente: "+ e.getMessage());
            return null;
        }
        
    }
    public List<Paciente> getPaciente(){
        String sql = "SELECT * FROM paciente";
        try{
          PreparedStatement stmt = this.conn.prepareStatement(sql);
          ResultSet rs = stmt.executeQuery();
          List<Paciente> listaPaciente = new ArrayList<>();
          while(rs.next()){
              Paciente p = new Paciente();
              p.setIdPaciente(rs.getInt("id_Paciente"));
              p.setNome(rs.getString("nome"));
              p.setDataNascimento(rs.getString("data_nasc"));
              p.setTelefone(rs.getString("telefone"));
              p.setEmail(rs.getString("email"));
              p.setEndereco(rs.getString("endereco"));
              listaPaciente.add(p);
          }
          return listaPaciente;
        }catch(Exception e){
            return null;
        }
    }
}
